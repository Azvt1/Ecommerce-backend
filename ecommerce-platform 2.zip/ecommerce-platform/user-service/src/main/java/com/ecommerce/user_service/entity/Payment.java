package com.ecommerce.user_service.entity;

import jakarta.persistence.*;

@Entity
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long paymentId;

    private Double paymentAmount;
    private String paymentStatus; // PENDING, COMPLETED, FAILED

    @Column(nullable = false)
    private Long orderId;

    @Column(nullable = false)
    private Long userId;

    public Payment(Long paymentId, Double paymentAmount, String paymentStatus, Long orderId, Long userId) {
        this.paymentId = paymentId;
        this.paymentAmount = paymentAmount;
        this.paymentStatus = paymentStatus;
        this.orderId = orderId;
        this.userId = userId;
    }

    public Payment() {}

    public Long getPaymentId() {
        return paymentId;
    }

    public Double getPaymentAmount() {
        return paymentAmount;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public Long getOrderId() {
        return orderId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setPaymentId(Long paymentId) {
        this.paymentId = paymentId;
    }

    public void setPaymentAmount(Double paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}