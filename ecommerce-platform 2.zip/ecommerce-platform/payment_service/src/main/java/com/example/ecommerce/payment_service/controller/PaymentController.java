package com.example.ecommerce.payment_service.controller;

import com.example.ecommerce.payment_service.Dto.PaymentRequest;
import com.example.ecommerce.payment_service.entity.Payment;
import com.example.ecommerce.payment_service.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/payments")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @GetMapping("/user/{userId}")
    public List<Payment> getOutstandingPayments(@PathVariable Long userId) {
        return paymentService.getOutstandingPaymentsForUser(userId);
    }

    @PostMapping("/{userId}/makePayment")
    public String makePayment(@RequestBody PaymentRequest paymentRequest) {
        return paymentService.makePayment(paymentRequest);
    }

    @PostMapping("/{userId}/order/{orderId}/cancel")
    public String cancelPayment(@PathVariable Long userId, @PathVariable Long orderId) {
        return paymentService.cancelPayment(userId, orderId);
    }
}
