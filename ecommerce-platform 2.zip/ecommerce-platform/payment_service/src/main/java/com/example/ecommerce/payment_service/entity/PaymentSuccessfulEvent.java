package com.example.ecommerce.payment_service.entity;

import com.example.ecommerce.payment_service.Dto.OrderItemDTO;

import java.util.List;

public class PaymentSuccessfulEvent {
    private Long orderId;
    private List<OrderItemDTO> items;


    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public void setItems(List<OrderItemDTO> items) {
        this.items = items;
    }

    public Long getOrderId() {
        return orderId;
    }

    public List<OrderItemDTO> getItems() {
        return items;
    }

    public PaymentSuccessfulEvent() {}
    public PaymentSuccessfulEvent(Long orderId, List<OrderItemDTO> items) {
        this.orderId = orderId;
        this.items = items;
    }
}

