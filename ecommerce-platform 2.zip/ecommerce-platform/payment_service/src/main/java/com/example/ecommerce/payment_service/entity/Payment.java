package com.example.ecommerce.payment_service.entity;

import com.example.ecommerce.payment_service.Dto.DeductionItemsFromStockDTO;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long paymentId;

    private Double paymentAmount;
    private String paymentStatus; // PENDING, COMPLETED, FAILED

    @Column(nullable = false)
    private Long userId;

    @Column(nullable = false)
    private Long orderId;


    public Payment() {}
    public Payment(Long paymentId, Double paymentAmount, String paymentStatus, Long userId, Long orderId) {
        this.paymentId = paymentId;
        this.paymentAmount = paymentAmount;
        this.paymentStatus = paymentStatus;
        this.userId = userId;
        this.orderId = orderId;
    }

    public void setPaymentId(Long paymentId) {
        this.paymentId = paymentId;
    }

    public void setPaymentAmount(Double paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getPaymentId() {
        return paymentId;
    }

    public Double getPaymentAmount() {
        return paymentAmount;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public Long getUserId() {
        return userId;
    }

    public Long getOrderId() {
        return orderId;
    }
}
