package com.example.ecommerce.payment_service.Dto;

import java.util.List;

public class UpdateInventoryDTO {

    private List<DeductionItemsFromStockDTO> itemList;

    private Long orderId;


    public void setItemList(List<DeductionItemsFromStockDTO> itemList) {
        this.itemList = itemList;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public List<DeductionItemsFromStockDTO> getItemList() {
        return itemList;
    }

    public Long getOrderId() {
        return orderId;
    }

    public UpdateInventoryDTO() {}

    public UpdateInventoryDTO(List<DeductionItemsFromStockDTO> itemList, Long orderId) {
        this.itemList = itemList;
        this.orderId = orderId;
    }
}
