package com.example.ecommerce.payment_service.service;

import com.example.ecommerce.payment_service.Dto.DeductionItemsFromStockDTO;
import com.example.ecommerce.payment_service.Dto.OrderItemDTO;
import com.example.ecommerce.payment_service.Dto.PaymentRequest;
import com.example.ecommerce.payment_service.Dto.OrderCreatedEvent;
import com.example.ecommerce.payment_service.entity.Payment;
import com.example.ecommerce.payment_service.entity.PaymentSuccessfulEvent;
import com.example.ecommerce.payment_service.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collectors;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;


    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private StreamBridge streamBridge;


    public PaymentService(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    @Value("${user.service.url}")
    private String userServiceUrl;



    public String makePayment(PaymentRequest paymentRequest) {

        Long userId = paymentRequest.getUserId();
        Double paymentAmount = paymentRequest.getAmount();

        String finalResult = "";
        try {
            String url = String.format("%s/%d/exists", userServiceUrl, userId);
            System.out.println("URL: " + url);

            Boolean userExists = restTemplate.getForObject(url, Boolean.class);


            if (userExists == null || !userExists) {
                return "User not found.";
            }
        } catch (Exception e) {
            return "Error checking user:" + e.getMessage();
        }
        List<Payment> allPayments = paymentRepository.findByUserId(userId);
        List<Payment> outstandingPayments = allPayments.stream().filter(payment -> "PENDING".equals(payment.getPaymentStatus()))
                .collect(Collectors.toList());

        if (outstandingPayments.isEmpty()) {
            return "No outstanding payments for this user.";
        }



        Payment payment = outstandingPayments.get(0);
        Double totalAmountDue = payment.getPaymentAmount();

        if (paymentAmount < totalAmountDue) {
            return "Fund insufficient. You need to pay: " + (totalAmountDue - paymentAmount);
        } else if (paymentAmount > totalAmountDue) {
            Double extraAmount = paymentAmount - totalAmountDue;
            payment.setPaymentStatus("COMPLETED");
            paymentRepository.save(payment);
            finalResult = "Payment successful. Extra amount " + extraAmount + " returned.";

        } else {
            // Exact amount paid
            payment.setPaymentStatus("COMPLETED");
            paymentRepository.save(payment);
            finalResult = "Payment successful.";
        }

        return finalResult;
    }

//    @Bean Consumer<List<DeductionItemsFromStockDTO>> updateStock() {
//        return allocatedQuantities -> {
//            allocatedQuantities.forEach(item -> {
//                System.out.println(item.getQuantityToRemove());
//            });
//        };
//    }

    public String cancelPayment(Long userId, Long orderId) {
        // Fetch the payment based on userId and orderId
        Payment payment = paymentRepository.findByUserIdAndOrderId(userId, orderId);

        if (payment == null) {
            return "Payment not found.";
        }

        // Check if the payment is in PENDING status
        if ("PENDING".equals(payment.getPaymentStatus())) {
            payment.setPaymentStatus("CANCELED"); // Update the status to CANCELED
            paymentRepository.save(payment);      // Save the updated payment
            return "Payment successfully canceled.";
        } else {
            return "Payment cannot be canceled. Status is not 'PENDING'.";
        }
    }

    @Bean
    public Consumer<OrderCreatedEvent> processOrder() {
        return event-> {
            System.out.println("Received OrderCreatedEvent: " + event);

            System.out.println(event.getItemList());

            streamBridge.send("deductStock-out-0", event);

            // Create a payment object from the event

            Payment payment = new Payment();
            payment.setOrderId(event.getOrderId());
            payment.setUserId(event.getUserId());
            payment.setPaymentAmount(event.getTotalAmount());
            payment.setPaymentStatus("PENDING");

            paymentRepository.save(payment);
        };
    }


    // Method to get outstanding payments for a user
    public List<Payment> getOutstandingPaymentsForUser(Long userId) {
        return paymentRepository.findByUserId(userId);
    }
}

