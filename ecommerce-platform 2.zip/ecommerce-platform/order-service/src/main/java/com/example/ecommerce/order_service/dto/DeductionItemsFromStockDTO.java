package com.example.ecommerce.order_service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "productId", "quantityToRemove", "inventoryId", "itemList", "orderId" })
public class DeductionItemsFromStockDTO implements Serializable {
    private Long productId;
    private int quantityToRemove;
    private Long inventoryId;

    public DeductionItemsFromStockDTO() {}

    private Long orderId;

    public DeductionItemsFromStockDTO( Long productId, int quantityToRemove, Long inventoryId) {
        this.productId = productId;
        this.quantityToRemove = quantityToRemove;
        this.inventoryId = inventoryId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public void setQuantityToRemove(int quantityToRemove) {
        this.quantityToRemove = quantityToRemove;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Long getProductId() {
        return productId;
    }

    public int getQuantityToRemove() {
        return quantityToRemove;
    }

    public Long getInventoryId() {
        return inventoryId;
    }
}
