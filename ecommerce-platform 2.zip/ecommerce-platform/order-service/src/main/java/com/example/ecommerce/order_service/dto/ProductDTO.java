package com.example.ecommerce.order_service.dto;

public class ProductDTO {
    private Long productId;
    private double price;

    public ProductDTO(Long productId, double price) {
        this.productId = productId;
        this.price = price;
    }

    public ProductDTO() {}

    // Getters and setters
    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
