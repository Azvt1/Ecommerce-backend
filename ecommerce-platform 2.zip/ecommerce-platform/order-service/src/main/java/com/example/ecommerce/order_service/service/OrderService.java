package com.example.ecommerce.order_service.service;


import com.example.ecommerce.order_service.dto.*;
import com.example.ecommerce.order_service.entity.Order;
import com.example.ecommerce.order_service.entity.OrderCreatedEvent;
import com.example.ecommerce.order_service.entity.OrderItem;
import com.example.ecommerce.order_service.repository.OrderRepository;
import jakarta.transaction.Transactional;
import org.apache.kafka.common.errors.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cglib.core.Local;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class OrderService {

    private final OrderRepository orderRepository;

    @Value("${user.service.url}")
    private String userServiceUrl;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private KafkaTemplate<String, OrderCreatedEvent> kafkaTemplate;

    @Autowired
    private StreamBridge streamBridge;

    @Autowired
    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    @Transactional
    public Order createOrder(Order order) {
        Long userId = order.getUserId();

        try {
            Boolean exists = restTemplate.getForObject(userServiceUrl, Boolean.class, userId);

            if (exists == null || !exists) {
                throw new RuntimeException("Specified user does not exist, double check userId");
            }
        } catch (RestClientException ex) {
            throw new RuntimeException("Specified user does not exist, double check userId");
        }


        // Checking for stock availability

        double totalOrderPrice = 0;
        
        List<DeductionItemsFromStockDTO> allocatedQuantities = new ArrayList<>();

        for (OrderItem item : order.getOrderItems()) {
            Long productId = item.getProductId();
            int requestedQuantity = item.getQuantity();

            String stockCheckUrl = "http://localhost:8084/api/inventories/allocationOfProduct?productId=" + productId + "&requestedQuantity=" + requestedQuantity;
            ResponseEntity<Map<Long, Integer>> response = restTemplate.exchange(
                    stockCheckUrl,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<Map<Long, Integer>>() {}
            );

            if (response.getStatusCode() != HttpStatus.OK || response.getBody() == null || response.getBody().isEmpty()) {
                throw new RuntimeException("Out of stock for product ID: " + productId);
            }

            // key value, where key is inventoryID and value number to deduct
            Map<Long, Integer> singleItemQuantity = response.getBody();
            for (Map.Entry<Long, Integer> entry: singleItemQuantity.entrySet()) {
                Long inventoryId = entry.getKey();
                Integer quantityToReduct = entry.getValue();
                System.out.println("haha");
                allocatedQuantities.add(new DeductionItemsFromStockDTO(productId, quantityToReduct, inventoryId));
            }
            System.out.println("quantity: " + allocatedQuantities);

            // price
            String priceCheckUrl = "http://localhost:8084/api/products/" + productId;
            ResponseEntity<ProductDTO> responseEntity = restTemplate.getForEntity(priceCheckUrl, ProductDTO.class);
            ProductDTO productDTO = responseEntity.getBody();
            System.out.println("checking price url: " + productDTO.getPrice());

            if (productDTO == null) {
                throw new RuntimeException("Product not found for productId:" + productId);
            }

            double price = productDTO.getPrice();
            item.setPrice(price);
            totalOrderPrice += price * item.getQuantity();
            item.setOrder(order);

        }
        order.setTotalAmount(totalOrderPrice);
        order.setOrderStatus("PENDING");
        order.setOrderDate(LocalDate.now());
        Order savedOrder = orderRepository.save(order);
        OrderCreatedEvent event = new OrderCreatedEvent();
        event.setOrderId(savedOrder.getOrderId());
        event.setUserId(savedOrder.getUserId());
        event.setTotalAmount(savedOrder.getTotalAmount());
        event.setItemList(allocatedQuantities);
        event.setOrderId(savedOrder.getOrderId());
        streamBridge.send("sendOrder-out-0", event);
//        streamBridge.send("sendAllocatedQuantities-out-0", allocatedQuantities);
        return savedOrder;
    }

    public OrderDTO getOrderById(Long orderId) {
        Order order = orderRepository.findById(orderId).orElseThrow(() -> new ResourceNotFoundException("Order not found"));

        return OrderMapper.toOrderDTO(order);
    }

    public void deleteOrder(Long orderId) {
        orderRepository.deleteById(orderId);
    }

}