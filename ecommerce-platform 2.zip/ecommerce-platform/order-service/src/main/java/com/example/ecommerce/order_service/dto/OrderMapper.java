package com.example.ecommerce.order_service.dto;

import com.example.ecommerce.order_service.entity.Order;
import com.example.ecommerce.order_service.entity.OrderItem;

import java.util.List;
import java.util.stream.Collectors;

public class OrderMapper {

    public static OrderDTO toOrderDTO(Order order) {
        OrderDTO dto = new OrderDTO();
        dto.setOrderId(order.getOrderId());
        dto.setOrderStatus(order.getOrderStatus());
        dto.setOrderDate(order.getOrderDate());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setUserId(order.getUserId());

        List<OrderItemDTO> orderItems = order.getOrderItems().stream()
                .map(OrderMapper::toOrderItemDTO)
                .collect(Collectors.toList());
        dto.setOrderItems(orderItems);

        return dto;
    }

    public static OrderItemDTO toOrderItemDTO(OrderItem item) {
        OrderItemDTO dto = new OrderItemDTO();
        dto.setOrderItemId(item.getOrderItemId());
        dto.setProductId(item.getProductId());
        dto.setQuantity(item.getQuantity());
        dto.setPrice(item.getPrice());
        dto.setOrderId(item.getOrder().getOrderId());  // Set orderId instead of order object

        return dto;
    }
}
