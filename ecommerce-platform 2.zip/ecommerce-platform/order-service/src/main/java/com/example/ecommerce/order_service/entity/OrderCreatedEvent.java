package com.example.ecommerce.order_service.entity;

import com.example.ecommerce.order_service.dto.DeductionItemsFromStockDTO;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"userId", "totalAmount", "itemList", "orderId" })
public class OrderCreatedEvent {
    private Long userId;
    private Double totalAmount;

    private List<DeductionItemsFromStockDTO> itemList;

    private Long orderId;





//    private Long productId;
//
//    private int quantityToRemove;
//
//    private Long inventoryId;

    public OrderCreatedEvent(Long orderId, Long userId, Double totalAmount, Long productId, int quantityToRemove, Long inventoryId) {
        this.orderId = orderId;
        this.userId = userId;
        this.totalAmount = totalAmount;
    }

    public void setItemList(List<DeductionItemsFromStockDTO> itemList) {
        this.itemList = itemList;
    }

    public List<DeductionItemsFromStockDTO> getItemList() {
        return itemList;
    }

    //    public void setProductId(Long productId) {
//        this.productId = productId;
//    }
//
//    public void setQuantityToRemove(int quantityToRemove) {
//        this.quantityToRemove = quantityToRemove;
//    }
//
//    public void setInventoryId(Long inventoryId) {
//        this.inventoryId = inventoryId;
//    }

//    public Long getProductId() {
//        return productId;
//    }
//
//    public int getQuantityToRemove() {
//        return quantityToRemove;
//    }
//
//    public Long getInventoryId() {
//        return inventoryId;
//    }

    public OrderCreatedEvent() {}

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public Long getOrderId() {
        return orderId;
    }

    public Long getUserId() {
        return userId;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    @Override
    public String toString() {
        return "OrderCreatedEvent{" +
                "orderId=" + orderId +
                ", userId=" + userId +
                ", totalAmount=" + totalAmount +
                '}';
    }

}
