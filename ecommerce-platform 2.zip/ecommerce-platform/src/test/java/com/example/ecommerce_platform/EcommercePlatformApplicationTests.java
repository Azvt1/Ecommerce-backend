package com.example.ecommerce_platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommercePlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
