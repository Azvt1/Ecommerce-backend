package com.example.ecommerce.product_service.DTO;


import com.fasterxml.jackson.annotation.JsonProperty;

public class DeductionItemsFromStockDTO {
    @JsonProperty("productId")
    private Long productId;
    @JsonProperty("quantityToRemove")
    private int quantityToRemove;
    @JsonProperty("inventoryId")
    private Long inventoryId;

    public DeductionItemsFromStockDTO() {}

    public DeductionItemsFromStockDTO(Long productId, int quantityToRemove, Long inventoryId) {
        this.productId = productId;
        this.quantityToRemove = quantityToRemove;
        this.inventoryId = inventoryId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public void setQuantityToRemove(int quantityToRemove) {
        this.quantityToRemove = quantityToRemove;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Long getProductId() {
        return productId;
    }

    public int getQuantityToRemove() {
        return quantityToRemove;
    }

    public Long getInventoryId() {
        return inventoryId;
    }
}
