package com.example.ecommerce.product_service.controller;

import com.example.ecommerce.product_service.DTO.ProductQuantityDTO;
import com.example.ecommerce.product_service.entity.Inventory;
import com.example.ecommerce.product_service.entity.Product;
import com.example.ecommerce.product_service.repository.InventoryProductRepository;
import com.example.ecommerce.product_service.service.InventoryService;
import com.example.ecommerce.product_service.service.ProductService;
import org.apache.kafka.common.errors.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.ecommerce.product_service.entity.InventoryProduct;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/inventories")
public class InventoryController {

    @Autowired
    private InventoryService inventoryService;

    @Autowired
    InventoryProductRepository inventoryProductRepository;

    @PostMapping
    public ResponseEntity<Inventory> createInventory(@RequestBody Map<String, String> request) {
        String warehouseLocation = request.get("warehouseLocation");
        Inventory newInventory = inventoryService.createInventory(warehouseLocation);
        return ResponseEntity.ok(newInventory);
    }

    @PostMapping("/{inventoryId}/products")
    public ResponseEntity<InventoryProduct> addProductToInventory(
            @PathVariable Long inventoryId,
            @RequestBody Product product,
            @RequestParam int quantity) {

        InventoryProduct inventoryProduct = inventoryService.addProductToInventory(inventoryId, product, quantity);
        return ResponseEntity.ok(inventoryProduct);
    }

    @GetMapping("/{inventoryId}/products")
    public ResponseEntity<Map<String, ProductQuantityDTO>> getInventoryProducts(@PathVariable Long inventoryId) {
        Map<String, ProductQuantityDTO> productQuantities = inventoryService.getInventoryProducts(inventoryId);
        return ResponseEntity.ok(productQuantities);
    }

    @GetMapping
    public List<Inventory> getAllInventories() {
        return inventoryService.getAllInventories();
    }

    @GetMapping("/products")
    public List<ProductQuantityDTO> getAllInventoriesWithTheirProducts() {
        return inventoryService.getAllInventoriesWithTheirProducts();
    }

    @GetMapping("/getInventoryProduct")
    public List<InventoryProduct> getAllInventoryProduct() {
        return inventoryProductRepository.findAll();
    }


    @GetMapping("/getInventoryProduct/{inventoryId}")
    public List<InventoryProduct> getAllInventoryProductById(@PathVariable Long inventoryId) {
        return inventoryProductRepository.findAllById(Collections.singleton(inventoryId));
    }

    @GetMapping("/productId/{productId}")
    public List<ProductQuantityDTO> getInventoriesOfSpecificProduct(@PathVariable Long productId) {
        return inventoryService.getInventoriesOfSpecificProduct(productId);
    }

    @GetMapping("/allocationOfProduct")
    public Map<Long, Integer> checkAndAllocateStock(@RequestParam Long productId, @RequestParam int requestedQuantity) {
        return inventoryService.checkAndAllocateStock(productId, requestedQuantity);
    }

}

