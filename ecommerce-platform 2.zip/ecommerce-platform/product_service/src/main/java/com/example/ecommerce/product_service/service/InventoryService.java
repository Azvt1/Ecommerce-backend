package com.example.ecommerce.product_service.service;

import com.example.ecommerce.product_service.DTO.DeductionItemsFromStockDTO;
import com.example.ecommerce.product_service.DTO.OrderCreatedEvent;
import com.example.ecommerce.product_service.DTO.ProductQuantityDTO;
import com.example.ecommerce.product_service.entity.Inventory;
import com.example.ecommerce.product_service.entity.InventoryProduct;
import com.example.ecommerce.product_service.entity.Product;
import com.example.ecommerce.product_service.repository.InventoryProductRepository;
import com.example.ecommerce.product_service.repository.InventoryRepository;
import jakarta.transaction.Transactional;
import org.apache.kafka.common.errors.ResourceNotFoundException;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.*;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;

@Service
public class InventoryService {

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private InventoryProductRepository inventoryProductRepository;

    @Autowired
    private ProductService productService;

    @Autowired
    private RestTemplate restTemplate;


    public Inventory createInventory(String warehouseLocation) {
        Inventory inventory = new Inventory();
        inventory.setWarehouseLocation(warehouseLocation);
        return inventoryRepository.save(inventory);
    }

    public InventoryProduct addProductToInventory(Long inventoryId, Product product, int quantity) {
        Inventory inventory = inventoryRepository.findById(inventoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory not found"));

        // Find or create an InventoryProduct for the given inventory
        InventoryProduct inventoryProduct = inventoryProductRepository.findByInventory(inventory)
                .stream().findFirst().orElse(new InventoryProduct(inventory));

        // Add the product and its quantity to the inventory product
        inventoryProduct.addProduct(product, quantity);

        return inventoryProductRepository.save(inventoryProduct);
    }


    public Map<String, ProductQuantityDTO> getInventoryProducts(Long inventoryId) {
        Inventory inventory = inventoryRepository.findById(inventoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory not found"));

        List<InventoryProduct> inventoryProducts = inventoryProductRepository.findByInventory(inventory);

        // If the list is empty, throw an exception
        if (inventoryProducts.isEmpty()) {
            throw new ResourceNotFoundException("InventoryProduct not found");
        }

        InventoryProduct inventoryProduct = inventoryProducts.get(0);

        Map<String, ProductQuantityDTO> productQuantitiesDTO = new HashMap<>();

        inventoryProduct.getProductQuantities().forEach((product, quantity) -> {
            productQuantitiesDTO.put(product.getProductName(), new ProductQuantityDTO(product, quantity));
        });

        return productQuantitiesDTO;
    }

    public List<ProductQuantityDTO> getAllInventoriesWithTheirProducts() {
        List<InventoryProduct> inventoryProducts = inventoryProductRepository.findAll();

        return inventoryProducts.stream()
                .flatMap(inventoryProduct ->
                        inventoryProduct.getProductQuantities().entrySet().stream()
                                .map(entry -> new ProductQuantityDTO(
                                        inventoryProduct.getInventory().getInventoryId(),  // Assuming InventoryProduct has a reference to its Inventory
                                        entry.getKey().getProductId(),
                                        entry.getValue()
                                ))
                )
                .collect(Collectors.toList());
    }

    public List<Inventory> getAllInventories() {
        return inventoryRepository.findAll();
    }


    public List<ProductQuantityDTO> getInventoriesOfSpecificProduct(Long productId) {
        List<InventoryProduct> inventoryProducts = inventoryProductRepository.findAll();

        return inventoryProducts.stream()
                .filter(inventoryProduct -> inventoryProduct.getProductQuantities().containsKey(
                        productService.getProductById(productId)
                                .orElseThrow(() -> new RuntimeException("Product not found"))
                ))
                .map(inventoryProduct -> {
                    Integer quantity = inventoryProduct.getProductQuantities().get(
                            productService.getProductById(productId).orElseThrow(() -> new RuntimeException("Product not found"))
                    );
                    return new ProductQuantityDTO(
                            inventoryProduct.getInventory().getInventoryId(),
                            productId,
                            quantity
                    );
                })
                .collect(Collectors.toList());
    }

    public Map<Long, Integer> checkAndAllocateStock(Long productId, int requestedQuantity) {
        List<ProductQuantityDTO> inventoryProducts = getInventoriesOfSpecificProduct(productId);
        int remainingQuantity = requestedQuantity;
        Map<Long, Integer> allocatedQuantities = new HashMap<>();

        for (ProductQuantityDTO inventoryProduct : inventoryProducts) {
            int availableQuantity = inventoryProduct.getQuantity();
            if (availableQuantity > 0) {
                int allocatedQuantity = Math.min(availableQuantity, remainingQuantity);
                allocatedQuantities.put(inventoryProduct.getInventoryId(), allocatedQuantity);
                remainingQuantity -= allocatedQuantity;
            }

            if (remainingQuantity <= 0) {
                break;
            }
        }

        if (remainingQuantity > 0) {
            // Not enough stock available
            throw new RuntimeException("Out of stock for product ID: " + productId);
        }

        return allocatedQuantities;
    }

    @Transactional
    public void updateStock(Long inventoryId, Long productId, Integer numberToDeduct) {
        List<InventoryProduct> inventoryProducts = inventoryProductRepository.findAll();

        inventoryProducts.forEach(inventoryProduct -> {
            if (inventoryProduct.getInventory().getInventoryId().equals(inventoryId)) {
                Map<Product, Integer> productQuantities = inventoryProduct.getProductQuantities();

                productQuantities.entrySet().forEach(entry -> {
                    Product product = entry.getKey();
                    Integer currentQuantity = entry.getValue();

                    if (product.getProductId().equals(productId)) {
                        if (currentQuantity != null && currentQuantity >= numberToDeduct) {
                            int updatedQuantity = currentQuantity - numberToDeduct;
                            productQuantities.put(product, updatedQuantity);

                            // Save the updated inventoryProduct to persist changes
                            inventoryProductRepository.save(inventoryProduct);

                            System.out.println("Successfully deducted " + numberToDeduct
                                    + " units of product ID " + productId
                                    + " from inventory ID " + inventoryId);
                        } else {
                            System.out.println("Insufficient stock for product ID "
                                    + productId + " in inventory ID " + inventoryId);
                        }
                    }
                });
            }
        });
    }

    @Bean
    public Consumer<OrderCreatedEvent> deductStock() {
        return orderCreatedEvent -> {
            System.out.println("received stock deduction request" + orderCreatedEvent);
            System.out.println(orderCreatedEvent.getItemList().get(0).getInventoryId());
            Long orderId = orderCreatedEvent.getOrderId();
            List<DeductionItemsFromStockDTO> itemList = orderCreatedEvent.getItemList();
            System.out.println("itemlist");
            System.out.println(itemList);

            itemList.forEach(item -> {
                Long inventoryId = item.getInventoryId();
                Long productId = item.getProductId();
                int quantityToRemove = item.getQuantityToRemove();

                updateStock(inventoryId, productId, quantityToRemove);

//
//
//                List<InventoryProduct> inventoryProducts = inventoryProductRepository.findAll();


//                inventoryProducts.forEach(singleInventory -> {
//                    if (singleInventory.getInventory().getInventoryId().equals(inventoryId)) {
//                        System.out.println("worked");
//                        Product product = new Product();
//                        product.setProductId(productId);
//                        System.out.println("productQuantites");
//                        System.out.println(singleInventory.getProductQuantities());
//                        Integer currentStock = singleInventory.getProductQuantities().get(product);
//
//                        if (currentStock != null && currentStock >= quantityToRemove) {
//                            singleInventory.getProductQuantities().put(product, currentStock - quantityToRemove);
//                            inventoryProductRepository.save(singleInventory);
//
//                            System.out.println("Successfully deducted " + quantityToRemove + " units of product ID "
//                                    + productId + " from inventory ID " + inventoryId);
//                        } else {
//                            System.out.println("Insufficient stock for product ID " + productId + " in inventory ID " + inventoryId);
//                        }
//                    }
//                });
             });
        };
    }

}


