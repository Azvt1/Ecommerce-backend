package com.example.ecommerce.product_service.DTO;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.persistence.Entity;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"userId", "totalAmount", "itemList", "orderId" })
public class OrderCreatedEvent {
    private Long userId;
    private Double totalAmount;

    private List<DeductionItemsFromStockDTO> itemList;
    private Long orderId;


    public OrderCreatedEvent(Long orderId, Long userId, Double totalAmount) {
        this.orderId = orderId;
        this.userId = userId;
        this.totalAmount = totalAmount;
    }

    public List<DeductionItemsFromStockDTO> getItemList() {
        return itemList;
    }

    public void setItemList(List<DeductionItemsFromStockDTO> itemList) {
        this.itemList = itemList;
    }

    public OrderCreatedEvent() {}

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public Long getOrderId() {
        return orderId;
    }

    public Long getUserId() {
        return userId;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }
}
