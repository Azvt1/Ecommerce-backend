package com.example.ecommerce.product_service.DTO;

import com.example.ecommerce.product_service.entity.Product;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL) // ensures to not include Null in my JSON response

public class ProductQuantityDTO {
    private ProductDTO product;

    private Long productId;
    private Integer quantity;

    private Long inventoryId;

    // Constructor
    public ProductQuantityDTO(Product product, Integer quantity) {
        this.product = new ProductDTO(product);
        this.quantity = quantity;
    }

    public ProductQuantityDTO(Long inventoryId, Long productId, Integer quantity) {
        this.inventoryId = inventoryId;
        this.productId = productId;
        this.quantity = quantity;
    }


    public ProductQuantityDTO(Long productId, Integer quantity) {
        this.productId = productId;
        this.quantity = quantity;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public Long getProductId() {
        return productId;
    }

    public ProductDTO getProduct() {
        return product;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setProduct(ProductDTO product) {
        this.product = product;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}

