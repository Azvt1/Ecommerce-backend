package com.example.ecommerce.product_service.entity;

import jakarta.persistence.*;

import java.util.HashMap;
import java.util.Map;

@Entity
public class InventoryProduct {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "inventoryId", nullable = false)
    private Inventory inventory;


    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "inventory_product_quantity", joinColumns = @JoinColumn(name = "inventory_product_id"))
    @MapKeyJoinColumn(name = "product_id")
    @Column(name = "quantity")
    private Map<Product, Integer> productQuantities = new HashMap<>();

    // Constructors, Getters, Setters
    public InventoryProduct() {}

    public InventoryProduct(Inventory inventory) {
        this.inventory = inventory;
    }

    public void addProduct(Product product, Integer quantity) {
        productQuantities.merge(product, quantity, Integer::sum);
    }

    public Long getId() {
        return id;

    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public Map<Product, Integer> getProductQuantities() {
        return productQuantities;
    }

    public void setProductQuantities(Map<Product, Integer> productQuantities) {
        this.productQuantities = productQuantities;
    }
}

