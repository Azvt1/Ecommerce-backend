package com.example.ecommerce.product_service.config;
import com.example.ecommerce.product_service.entity.Inventory;
import com.example.ecommerce.product_service.entity.InventoryProduct;
import com.example.ecommerce.product_service.entity.Product;
import com.example.ecommerce.product_service.repository.InventoryProductRepository;
import com.example.ecommerce.product_service.repository.InventoryRepository;
import com.example.ecommerce.product_service.repository.ProductRepository;
import com.example.ecommerce.product_service.service.InventoryService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Autowired;

@Configuration
public class DataInitializer {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private InventoryProductRepository inventoryProductRepository;
    @Autowired
    private InventoryRepository inventoryRepository;


    @Bean
    public CommandLineRunner loadData() {
        return args -> {
            // Sample Products
            Product product1 = new Product("Laptop", "High-end gaming laptop", 1500.00);
            Product product2 = new Product("Smartphone", "Latest model smartphone", 799.99);
            productRepository.save(product1);
            productRepository.save(product2);

            // Sample Inventory
            Inventory inventory = new Inventory("Warehouse A");
            inventoryRepository.save(inventory);

            // Add products to inventory with quantities
            InventoryProduct inventoryProduct = new InventoryProduct(inventory);
            inventoryProduct.addProduct(product1, 50);
            inventoryProduct.addProduct(product2, 100);
            inventoryProductRepository.save(inventoryProduct);

            Product product3 = new Product("Ipad", "High-end gaming laptop", 1500.00);
            Product product4 = new Product("Charger", "Latest model smartphone", 799.99);
            productRepository.save(product3);
            productRepository.save(product4);

            // Sample Inventory
            Inventory inventory2 = new Inventory("Warehouse B");
            inventoryRepository.save(inventory2);

            // Add products to inventory with quantities
            InventoryProduct inventoryProduct2 = new InventoryProduct(inventory2);
            inventoryProduct2.addProduct(product2, 20);
            inventoryProduct2.addProduct(product4, 10);
            inventoryProductRepository.save(inventoryProduct2);
        };
    }


}

