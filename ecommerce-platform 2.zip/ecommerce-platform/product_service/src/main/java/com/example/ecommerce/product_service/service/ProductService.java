package com.example.ecommerce.product_service.service;

import com.example.ecommerce.product_service.DTO.OrderCreatedEvent;
import com.example.ecommerce.product_service.DTO.ProductQuantityDTO;
import com.example.ecommerce.product_service.entity.InventoryProduct;
import com.example.ecommerce.product_service.entity.Product;
import com.example.ecommerce.product_service.repository.InventoryProductRepository;
import com.example.ecommerce.product_service.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.*;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private InventoryProductRepository inventoryProductRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public Product saveProduct(Product product) {
        return productRepository.save(product);
    }

    public Optional<Product> getProductById(Long productId) {
        return productRepository.findById(productId);
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

//    public boolean isStockAvailable(Long productId, int requestedQuantity) {
//        List<ProductQuantityDTO> inventoryProduct = inventoryProductRepository.findBy
//    }

}

