package com.example.ecommerce.product_service.entity;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class Inventory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long inventoryId;
    private String warehouseLocation;

    @OneToMany(mappedBy = "inventory", cascade = CascadeType.ALL)
    private List<InventoryProduct> inventoryProducts;

    public Inventory(Product product, Integer stockQuantity, String warehouseLocation) {
        this.warehouseLocation = warehouseLocation;
    }

    public Inventory(String warehouseLocation) {
        this.warehouseLocation = warehouseLocation;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }


    public void setWarehouseLocation(String warehouseLocation) {
        this.warehouseLocation = warehouseLocation;
    }

    public Long getInventoryId() {
        return inventoryId;
    }


    public String getWarehouseLocation() {
        return warehouseLocation;
    }

    public Inventory() {}
    public Inventory(Long inventoryId, Product product, Integer stockQuantity, String warehouseLocation) {
        this.inventoryId = inventoryId;
        this.warehouseLocation = warehouseLocation;
    }
}

